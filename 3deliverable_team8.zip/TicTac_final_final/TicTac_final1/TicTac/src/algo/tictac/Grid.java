package algo.tictac;

import java.awt.Color;

public class Grid {

	private Tile[][] tiles = new Tile[3][3];
    private TileClick click ;

	public Grid(){
		click = new TileClick();
		intializeTiles();
		disableTiles();
		
	}

	private void intializeTiles() {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				tiles[i][j] = new Tile(i, j);	
				tiles[i][j].addActionListener(click);
			}
		}

	}

	public void enableDisableTiles(boolean enabled){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				tiles[i][j].setEnabled(enabled);
				if(enabled){
				tiles[i][j].setText(" ");
				tiles[i][j].setBackground(new Color(255, 255, 205));
				}
			}
		}
	}

	public void enableTiles(){
		enableDisableTiles(true);
	}

	public void disableTiles(){
		enableDisableTiles(false);
	}


	public Tile[][] getTiles(){
		return tiles;
	}





}
