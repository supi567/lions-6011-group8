package algo.tictac;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.Random;

import javax.swing.JOptionPane;

import javafx.embed.swing.JFXPanel;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;



// TODO: Auto-generated Javadoc
/**
 * The Class TileClick.
 * Author Amandeep Narula
 */
public class TileClick implements ActionListener{


	/**
	 * Instantiates a new tile click.
	 * 
	 */
	//	private AudioPlayer audioPlayer = AudioPlayer.player;
	//	private AudioStream audioStream ;
	//	private AudioData audioData;
	Media hit;
	MediaPlayer mediaPlayer ;
	private Player opponentPlayer;
	private DifficultyLevel diffLevel;
	private static int[][] tilesPos = new int[3][3];
	
	private static final int HumanCode=1;
	private static final int computerCode=2;

	public TileClick(){
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		Tile tile = (Tile) e.getSource();
        
		opponentPlayer = Game.opponentPlayer;
		diffLevel = Game.diffLevel;
		
		if(!tile.getText().equals(" ")){
			return;
		}
		
		

		if(Game.currentPlayer.equals(Player.Human)){
			playBackground(Game.currentPlayer);
			tilesPos[tile.getxVal()][tile.getyVal()] = HumanCode;
			tile.setText(Game.humanSymbol);
			
			int playerWon = checkGameState();
			if(playerWon ==1 || playerWon ==2 ){
                gameover(playerWon);
                return;
			}
			//Checks if opponent player is computer but not human and 
			//also reads the game
			if(opponentPlayer == Player.Computer){
				
				if(diffLevel == DifficultyLevel.HIGH){
				int pos[] = computerTurn();
				
				if(pos!=null){
				Game.getGrid().getTiles()[pos[0]][pos[1]].setText(Game.computerSymbol);
				
				playerWon = checkGameState();
				if(playerWon ==1 || playerWon ==2 ){
	                gameover(playerWon);
				}
				return;
				} 
				
				computerTurnLow();
				playerWon = checkGameState();
				if(playerWon ==1 || playerWon ==2 ){
	                gameover(playerWon);
	                return;
				}
				
				
//				for(int i=0;i<3;i++){
//					for(int j=0;j<3;j++){
//						if(Game.getGrid().getTiles()[i][j].getText().equals(" ")){
//							Game.getGrid().getTiles()[i][j].setText(Game.computerSymbol);
//							tilesPos[Game.getGrid().getTiles()[i][j].getxVal()][Game.getGrid().getTiles()[i][j].getyVal()] = computerCode;
//							playerWon = checkGameState();
//							if(playerWon ==1 || playerWon ==2 ){
//				                gameover(playerWon);
//							}
//							return;
//						}
//				}
//				}
				}
				else if(diffLevel == DifficultyLevel.LOW){
					computerTurnLow();
					playerWon = checkGameState();
					if(playerWon ==1 || playerWon ==2 ){
		                gameover(playerWon);
					}
					return;
				}
				else if(diffLevel == DifficultyLevel.MEDIUM){
					playMedium();	
					playerWon = checkGameState();
					if(playerWon ==1 || playerWon ==2 ){
		                gameover(playerWon);
					}
					return;
				}
				
			}
			else{
				Game.currentPlayer = Player.Human_2;
				Game.setStatus("Player 2's Turn!!");
			}
			
			

		}
		else if (Game.currentPlayer.equals(Player.Human_2)){
			playBackground(Game.currentPlayer);
			tile.setText("O");
			int playerWon = checkGameState();
			Game.currentPlayer = Player.Human;
			Game.setStatus("Player 1's Turn!!");
			if(playerWon ==1 || playerWon ==2 ){
                gameover(playerWon);
                return;
			}
		}
		
		if(checkTie()){
			JOptionPane.showMessageDialog(Game.getGameInstance(),
					"Game is tied",
				    "Game Result",
				    JOptionPane.WARNING_MESSAGE);
			resetTilesPos();
		}
	}

	private boolean checkTie() {
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if(Game.getGrid().getTiles()[i][j].getText().equals(" ")){
					return false;
				}
			}
		}
		return true;
		
	}

	private void computerTurnLow() {
		
		Random random = new Random();
		int min = 0;
		int max = 2;
		int iRandom = 0;
		int jRandom = 0;
		
		//iRandom = random.nextInt(max - min + 1) + min;
		//jRandom = random.nextInt(max - min + 1) + min;
		int emptyCount=0;
	
		for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			if(!Game.getGrid().getTiles()[i][j].getText().equals(" ")){	
			
			
				emptyCount++;
			}
			}
		}
		
		if(emptyCount==9){
			return;
		}
		while(!Game.getGrid().getTiles()[iRandom][jRandom].getText().equals(" ")){
			iRandom = random.nextInt(max - min + 1) + min;
			jRandom = random.nextInt(max - min + 1) + min;
		}	
		
		Game.getGrid().getTiles()[iRandom][jRandom].setText(Game.computerSymbol);
		tilesPos[iRandom][jRandom] = computerCode;
		
	}
	
	public static void resetTilesPos(){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				tilesPos[i][j] = 0;
				Game.getGrid().getTiles()[i][j].setText(" ");
			}
		}
	}

	private int[] computerTurn() {	
       	int[] pos= new int[2];
		
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if(tilesPos[i][j] == 0){				
					tilesPos[i][j] = HumanCode;
					if(isHumanWinning()){
						pos[0] = i;
						pos[1] = j;
						tilesPos[i][j] = computerCode;
						return pos;
						
					} else{
						tilesPos[i][j]=0;
					}
					
				}
			
			}
			}
		return null;
	}

	public void setTilesCode(int[][] tilesCode){
		tilesPos = tilesCode;
	}

	private boolean isHumanWinning() {
		



		

		int o_Count=0;
		//int x_Count=0;

		//Checks Horizontally

		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){

				if(tilesPos[i][j]==HumanCode){
					o_Count++;
					System.out.println(o_Count);
					if(o_Count==3){
						System.out.println("Human WON");
						return true;
					}
				}
//				else if(tiles[i][j].getText().equals("X")){
//					x_Count++;
//					System.out.println(o_Count);
//					if(x_Count==3){
//						System.out.println("HUMAN WON");
//						return 2;
//					}
//				}

			}
			o_Count=0;
			//x_Count=0;
		}

		//Checks Vertically

		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){

				if(tilesPos[j][i]==HumanCode){
					o_Count++;
					System.out.println(o_Count);
					if(o_Count==3){
						System.out.println("human WON");
						return true;
					}
				}
//				else if(tiles[j][i].getText().equals("X")){
//					x_Count++;
//					System.out.println(o_Count);
//					if(x_Count==3){
//						System.out.println("HUMAN WON");
//						return 2;
//					}
//				}

			}
			o_Count=0;
			//x_Count=0;
		}

		//Checks Diagonally

		if(tilesPos[0][0]==HumanCode &&
				tilesPos[1][1]==HumanCode &&
				tilesPos[2][2]==HumanCode){
			System.out.println("human WON");
			return true;
		}
//		else if(tiles[0][0].getText().equals("X") &&
//				tiles[1][1].getText().equals("X") &&
//				tiles[2][2].getText().equals("X")){
//			System.out.println("HUMAN WON");
//			return 2;
//		}


		if(tilesPos[0][2]==HumanCode &&
				tilesPos[1][1]==HumanCode &&
				tilesPos[2][0]==HumanCode){
			System.out.println("humAN WON");
			return true;
		}
//		else if(tiles[0][2].getText().equals("X") &&
//				tiles[1][1].getText().equals("X") &&
//				tiles[2][0].getText().equals("X")){
//			System.out.println("HUMAN WON");
//			return 2;
//		}

		return false;
	
	}

	private void gameover(int playerWon) {
		String displayResult="";
		SecureRandom random = new SecureRandom();
		String number = new BigInteger(30,random).toString();
		if(playerWon==1){
			displayResult= "Sorry!! You lose the game";
			
			Game.totalNumber.setText(String.valueOf(++Game.totalGames));
			Game.winCompNumber.setText(String.valueOf(++Game.computerWinGames));
			
		}
		if(opponentPlayer == Player.Computer && playerWon==2){
			displayResult="Congratulations !! You've Won Tim Horton's Gift Card worth 5$ " + "\n"
	                  + "Your card number is TIM_"+number;
			Game.totalNumber.setText(String.valueOf(++Game.totalGames));
			Game.winHumanNumber.setText(String.valueOf(++Game.humanWinGames));
		}
		if(opponentPlayer == Player.Human_2 && playerWon==2){
			displayResult="Congratulations !! Player 1 has won the game";
			Game.totalNumber.setText(String.valueOf(++Game.totalGames));
			Game.winHumanNumber.setText(String.valueOf(++Game.humanWinGames));
		}
		
		showWinMessage(displayResult);
		
		//Game.getGameInstance().dispose();
		resetTilesPos();
		
		checkBestWin(displayResult);
		
	}
	
	private void playMedium(){

		Tile[][] tiles = Game.getGrid().getTiles();

		int o_Count=0;

       
        
		//Checks Horizontally

		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
              
				if(tiles[i][j].getText().equals(Game.computerSymbol)){
					o_Count++;
				}
				System.out.println("O count1 "+o_Count);

			}
			if(o_Count==2){
				System.out.println("Horizonal 2");
				if(tiles[i][0].getText().equals("")){
					tiles[i][0].setText(Game.computerSymbol);
					tilesPos[i][0]=computerCode;
					return;
				} 
				else if(tiles[i][1].getText().equals("")){
					tiles[i][1].setText(Game.computerSymbol);
					tilesPos[i][1]=computerCode;
					return;
				} 
				
				else if(tiles[i][2].getText().equals("")){
					tiles[i][2].setText(Game.computerSymbol);
					tilesPos[i][2]=computerCode;
					return;
				} 
				 
				
			} else if(o_Count<2){
				if(checkVertical(2)){
					System.out.println("Vertical 2");
					return;
				} else if(checkDiagonalFor2()){
				   return;
				}
				else{
					System.out.println("Low");
					computerTurnLow();
					return;
				}
			}
			
//			if(checkVertical(2)){
//				return;
//			}
//			
//			if(checkDiagonalFor2()){
//				return;
//			}
//			
//            if(o_Count==1){
//            	
//            	if(checkVertical(1)){return;}
//            	
//            	
//            }
//		
            
          
			
			
			o_Count=0;
			
		
		}
//
//		//Checks Vertically
//        int numJ=0;
//		for(int i=0;i<3;i++){
//			for(int j=0;j<3;j++){
//                
//				if(tiles[j][i].getText().equals(Game.computerSymbol)){
//					o_Count++;
//					
//					
//				}
//				System.out.println("O count2 "+o_Count);
//				numJ=j;
//
//			}
//			if(o_Count==2){
//				if(tiles[0][numJ].getText().equals("")){
//					tiles[1][numJ].setText(Game.computerSymbol);
//					tilesPos[2][numJ]=computerCode;
//					return;
//				} 
//				else if(tiles[0][numJ].getText().equals("")){
//					tiles[1][numJ].setText(Game.computerSymbol);
//					tilesPos[2][numJ]=computerCode;
//					return;
//				} 
//				
//				else if(tiles[0][numJ].getText().equals("")){
//					tiles[1][numJ].setText(Game.computerSymbol);
//					tilesPos[2][numJ]=computerCode;
//					return;
//				} 
//				
//			}
//
//			o_Count=0;
//		  
//		}
//
//		//Checks Diagonally
//
//		if(tiles[0][0].getText().equals(Game.computerSymbol) &&
//				tiles[1][1].getText().equals(Game.computerSymbol) ){
//			tiles[2][2].setText(Game.computerSymbol);
//			tilesPos[2][2]=computerCode;
//			return;
//		
//		}
//		else if(tiles[0][0].getText().equals(Game.computerSymbol) &&
//				tiles[2][2].getText().equals(Game.computerSymbol)){
//			tiles[1][1].setText(Game.computerSymbol);
//			tilesPos[1][1]=computerCode;
//			return;
//		} 
//		else if(tiles[1][1].getText().equals(Game.computerSymbol) &&
//				tiles[2][2].getText().equals(Game.computerSymbol)){
//			tiles[0][0].setText(Game.computerSymbol);
//			tilesPos[0][0]=computerCode;
//			return;
//		} 
//
//
//		if(tiles[0][2].getText().equals(Game.computerSymbol) &&
//				tiles[1][1].getText().equals(Game.computerSymbol)){
//			
//			
//		}
//	
		
		
		

		
	}
		
		
	


	private boolean checkDiagonalFor2() {
		Tile[][] tiles = Game.getGrid().getTiles();
		if(tiles[0][0].getText().equals(Game.computerSymbol) &&
				tiles[1][1].getText().equals(Game.computerSymbol) ){
			tiles[2][2].setText(Game.computerSymbol);
			tilesPos[2][2]=computerCode;
			return true;
		
		}
		else if(tiles[0][0].getText().equals(Game.computerSymbol) &&
				tiles[2][2].getText().equals(Game.computerSymbol)){
			tiles[1][1].setText(Game.computerSymbol);
			tilesPos[1][1]=computerCode;
			return true;
		} 
		else if(tiles[1][1].getText().equals(Game.computerSymbol) &&
				tiles[2][2].getText().equals(Game.computerSymbol)){
			tiles[0][0].setText(Game.computerSymbol);
			tilesPos[0][0]=computerCode;
			return true;
		} 
		return false;
	}

	private boolean checkVertical(int noOfTiles) {
		Tile[][] tiles = Game.getGrid().getTiles();
		
		int o_Count=0;
        int numJ=0;
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
               
				if(tiles[j][i].getText().equals(Game.computerSymbol)){
					o_Count++;
					
					
				}
				System.out.println("O count2 "+o_Count);
				numJ=j;

			}
			if(o_Count==noOfTiles){
				if(tiles[0][numJ].getText().equals("")){
					tiles[0][numJ].setText(Game.computerSymbol);
					tilesPos[0][numJ]=computerCode;
					return true;
				} 
				else if(tiles[1][numJ].getText().equals("")){
					tiles[1][numJ].setText(Game.computerSymbol);
					tilesPos[1][numJ]=computerCode;
					return true;
				} 
				
				else if(tiles[2][numJ].getText().equals("")){
					tiles[2][numJ].setText(Game.computerSymbol);
					tilesPos[2][numJ]=computerCode;
					return true;
				} 
				
			}
//			else if(o_Count==2){
//				computerTurnLow();
//				return;
//			}
			o_Count=0;
		  numJ=0;
		}
		
		return false;
		
	}

	private void checkBestWin(String displayResult) {
		if(Game.selectedGameType==Game.GameType.SINGLE){
			
			if(Game.totalGames==1){
				if(Game.computerWinGames>Game.humanWinGames && Game.opponentPlayer==Player.Computer){
					displayResult = "Computer has won the single game"+"\n"+"Computer Won: "+Game.computerWinGames+"\n"+"Human Won: "+Game.humanWinGames;
					showWinMessage(displayResult);
				} else if(Game.computerWinGames>Game.humanWinGames && Game.opponentPlayer==Player.Human_2){
					displayResult = "Player2 has won the single game"+"\n"+"Player2 Won: "+Game.computerWinGames+"\n"+"Player1 Won: "+Game.humanWinGames;
					showWinMessage(displayResult);
				}
				else{
					displayResult = "Player1 has won the single game"+"\n"+"Player2 Won: "+Game.computerWinGames+"\n"+"Player1 Won: "+Game.humanWinGames;
					showWinMessage(displayResult);
					
				}
				
				resetWinNumbers();
			}
			
		} else if(Game.selectedGameType==Game.GameType.BEST3){
			
			if(Game.totalGames==3){
				if(Game.computerWinGames>Game.humanWinGames && Game.opponentPlayer==Player.Computer){
					displayResult = "Computer has won the Best of 3 game"+"\n"+"Computer Won: "+Game.computerWinGames+"\n"+"Human Won: "+Game.humanWinGames;
					showWinMessage(displayResult);
					
				} 
				else if(Game.computerWinGames>Game.humanWinGames && Game.opponentPlayer==Player.Human_2){
					displayResult = "Player2 has won the single game"+"\n"+"Player2 Won: "+Game.computerWinGames+"\n"+"Player1 Won: "+Game.humanWinGames;
					showWinMessage(displayResult);
				}
				else{
					displayResult = "Player1 has won the Best of 3 game"+"\n"+"Player2 Won: "+Game.computerWinGames+"\n"+"Player1 Won: "+Game.humanWinGames;
					showWinMessage(displayResult);
					
				}
				
				resetWinNumbers();
			}
			
			
		} else if(Game.selectedGameType==Game.GameType.BEST5){
			
			if(Game.totalGames==5){
				if(Game.computerWinGames>Game.humanWinGames && Game.opponentPlayer==Player.Computer){
					displayResult = "Computer has won the Best of 5 game"+"\n"+"Computer Won: "+Game.computerWinGames+"\n"+"Human Won: "+Game.humanWinGames;
					showWinMessage(displayResult);
					
				}
				else if(Game.computerWinGames>Game.humanWinGames && Game.opponentPlayer==Player.Human_2){
					displayResult = "Player2 has won the single game"+"\n"+"Player2 Won: "+Game.computerWinGames+"\n"+"Player1 Won: "+Game.humanWinGames;
					showWinMessage(displayResult);
				}
				else{
					displayResult = "Player1 has won the Best of 5 game"+"\n"+"Player2 Won: "+Game.computerWinGames+"\n"+"Player1 Won: "+Game.humanWinGames;
					showWinMessage(displayResult);
					
				}
				
				resetWinNumbers();
			}
			
		}
		
	}
	
	private void resetWinNumbers(){
		Game.totalGames=0;
		Game.computerWinGames=0;
		Game.humanWinGames=0;
		Game.totalNumber.setText("0");
		Game.winCompNumber.setText("0");
		Game.winHumanNumber.setText("0");
	}
	
	private void showWinMessage(String winMessage){
		JOptionPane.showMessageDialog(Game.getGameInstance(),
				winMessage,
			    "Game Result",
			    JOptionPane.WARNING_MESSAGE);
	}

	private void playBackground(Player player) {
		try{
			new JFXPanel();
			if(Game.currentPlayer.equals(Player.Human)){
				hit = new Media(Paths.get("beep3.mp3").toUri().toString());
				mediaPlayer = new MediaPlayer(hit);
				mediaPlayer.play();
			}
			else if(Game.currentPlayer.equals(Player.Computer)){
				hit = new Media(Paths.get("beep14.mp3").toUri().toString());
				mediaPlayer = new MediaPlayer(hit);
				mediaPlayer.play();
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}


	}

	/**
	 * Check game state.
	 *
	 * @return the int
	 */
	private int checkGameState() {


		Tile[][] tiles = Game.getGrid().getTiles();

		int o_Count=0;
		int x_Count=0;

		//Checks Horizontally

		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){

				if(tiles[i][j].getText().equals(Game.computerSymbol)){
					o_Count++;
					System.out.println(o_Count);
					if(o_Count==3){
						System.out.println("COMPUTER WON");
						return 1;
					}
				}
				else if(tiles[i][j].getText().equals(Game.humanSymbol)){
					x_Count++;
					System.out.println(o_Count);
					if(x_Count==3){
						System.out.println("HUMAN WON");
						return 2;
					}
				}

			}
			o_Count=0;
			x_Count=0;
		}

		//Checks Vertically

		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){

				if(tiles[j][i].getText().equals(Game.computerSymbol)){
					o_Count++;
					System.out.println(o_Count);
					if(o_Count==3){
						System.out.println("COMPUTER WON");
						return 1;
					}
				}
				else if(tiles[j][i].getText().equals(Game.humanSymbol)){
					x_Count++;
					System.out.println(o_Count);
					if(x_Count==3){
						System.out.println("HUMAN WON");
						return 2;
					}
				}

			}
			o_Count=0;
			x_Count=0;
		}

		//Checks Diagonally

		if(tiles[0][0].getText().equals(Game.computerSymbol) &&
				tiles[1][1].getText().equals(Game.computerSymbol) &&
				tiles[2][2].getText().equals(Game.computerSymbol)){
			System.out.println("COMPUTER WON");
			return 1;
		}
		else if(tiles[0][0].getText().equals(Game.humanSymbol) &&
				tiles[1][1].getText().equals(Game.humanSymbol) &&
				tiles[2][2].getText().equals(Game.humanSymbol)){
			System.out.println("HUMAN WON");
			return 2;
		}


		if(tiles[0][2].getText().equals(Game.computerSymbol) &&
				tiles[1][1].getText().equals(Game.computerSymbol) &&
				tiles[2][0].getText().equals(Game.computerSymbol)){
			System.out.println("COMPUTER WON");
			return 1;
		}
		else if(tiles[0][2].getText().equals(Game.humanSymbol) &&
				tiles[1][1].getText().equals(Game.humanSymbol) &&
				tiles[2][0].getText().equals(Game.humanSymbol)){
			System.out.println("HUMAN WON");
			return 2;
		}

		return 0;
	}
}
