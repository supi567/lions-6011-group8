package algo.tictac;



import javax.swing.JButton;

public class Tile extends JButton {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//private TileClick click = new TileClick();
	

	public Tile(int xVal,int yVal){
		super();
		this.xVal = xVal;
		this.yVal = yVal;
		//addActionListener(this);
	}

	private int xVal;
	public int getxVal() {
		return xVal;
	}

	public void setxVal(int xVal) {
		this.xVal = xVal;
	}

	public int getyVal() {
		return yVal;
	}

	public void setyVal(int yVal) {
		this.yVal = yVal;
	}

	private int yVal;

	@Override
	public void setText(String text){
		super.setText(text);
	}

//	@Override
//	public void actionPerformed(ActionEvent e) {
//		Tile tile = (Tile) e.getSource();
//		
//		if(tile.getText()!=" "){
//			System.out.println("Can't make move");
//		}
//
//		if(game.getCurrentPlayer().equals(Player.Human)){	    
//			tile.setText("X");
//			Game.player = Player.Computer;
//		}
//		else if (game.getCurrentPlayer().equals(Player.Computer)){
//			tile.setText("O");
//			Game.player = Player.Human;
//		}
//	}



}
