package algo.tictac;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.file.Paths;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import javafx.embed.swing.JFXPanel;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

// TODO: Auto-generated Javadoc
/**
 * The Class Game.
 * Author Amandeep Narula
 */
public class Game extends JFrame implements ActionListener{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The grid. */
	private static Grid grid;

	/** The tiles. */
	private Tile[][] tiles;

	/** The player. */
	public static Player currentPlayer;

	public static Player opponentPlayer;

	public static DifficultyLevel diffLevel;

	private boolean isLevelSelected = false;

	private boolean isPlayerSelected = false;
	
	private boolean isGameTypeSelected = false;
	
	public static int totalGames = 0;
	
	public static int computerWinGames = 0;
	
	public static int humanWinGames = 0;
	
	JComboBox<String> symbolCombo;
	

	private String helpText = "Tic-tac-toe (also known as Noughts and crosses" + "\n"
			+ " or Xs and Os) is a  game for two players" + "\n"
			+ " X and O, who take turns marking the spaces in a 3�3 grid. " + "\n"
			+ "The player who succeeds in placing three of their marks in a " + "\n"
			+ "horizontal, vertical, or diagonal row wins the game" 
			+ "\n"
			+ "Game of Tic-tac-toe, won by X" + "\n" +
			" The winner will get a gift";

	public static String computerSymbol = "O";
	
	public static String humanSymbol = "X";

	/** The status label. */
	private static JLabel statusLabel = new JLabel("");

	/** The play button. */
	JButton playButton = new JButton("Play");

	JButton helpButton = new JButton("Help");

	JButton exitButton = new JButton("Exit");
	
	JLabel winHumanGames;
	JLabel winCompGames;
	
	public static JLabel totalNumber;
	
	public static JLabel winCompNumber;
	
	public static JLabel winHumanNumber;

	/** The game. */
	private static Game game = new Game();
	
	public static GameType selectedGameType;

	Media hit;
	MediaPlayer mediaPlayer ;

	/**
	 * Gets the grid.
	 *
	 * @return the grid
	 */
	public static Grid getGrid(){
		return grid;
	}

	public static Game getGameInstance(){
		return game;
	}
	
	public enum GameType{
		SINGLE,BEST3,BEST5
	}

	/**
	 * Instantiates a new game.
	 */
	private Game(){

		
		grid = new Grid();
		setTitle("Tic Tac Toe");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		JPanel gridPanel = new JPanel(new GridLayout(3,3));
		Font font = new Font("Arial",Font.BOLD, 32);


		tiles = grid.getTiles();
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++) {

				tiles[i][j].setFocusable(false);
				tiles[i][j].setFont(font);
				gridPanel.add(tiles[i][j]);
			}
		}

		setSize(650,600);
		this.add(gridPanel);

        JPanel controlPanel = new JPanel();
        JPanel bottomPanel = new JPanel();

		JPanel labelPanel = new JPanel();

		labelPanel.add(statusLabel);

		JPanel playButtonPanel = new JPanel();
		playButtonPanel.add(playButton);
		playButtonPanel.add(helpButton);
		playButtonPanel.add(exitButton);
		playButton.setEnabled(false);
		playButtonPanel.setBackground(new Color(255, 255, 219));
		setStatus("Click 'Play' To Start");


		
		final DefaultComboBoxModel<String> gameType = new DefaultComboBoxModel<String>();

		gameType.addElement("SELECT GAME");
		gameType.addElement("SINGLE");
		gameType.addElement("BEST of 3");
		gameType.addElement("BEST of 5");

		final JComboBox<String> gameTypeCombo = new JComboBox<String>(gameType);    

		gameTypeCombo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				isGameTypeSelected = true;

				JComboBox<String> jcombo = (JComboBox<String>) e.getSource();

				if(String.valueOf(jcombo.getSelectedItem()).equals("SINGLE")){
					selectedGameType = GameType.SINGLE;setTitle("Tic Tac Toe - SINGLE");}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("BEST of 3")){
					selectedGameType = GameType.BEST3;setTitle("Tic Tac Toe - BEST of 3");}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("BEST of 5")){
					selectedGameType = GameType.BEST5;setTitle("Tic Tac Toe - BEST of 5");
				} else if(String.valueOf(jcombo.getSelectedItem()).equals("SELECT GAME")){
					isGameTypeSelected= false;
				}

				if(isPlayerSelected && isGameTypeSelected){
					if(opponentPlayer == Player.Computer && isLevelSelected){
					playButton.setEnabled(true);
					}
					else if(opponentPlayer == Player.Human_2){
						playButton.setEnabled(true);
					}
					else{
						playButton.setEnabled(false);
					}
				}
				else{
					playButton.setEnabled(false);
				}



			}
		});

		JScrollPane gameTypeScrollPane = new JScrollPane(gameTypeCombo); 
		
		
        
		final DefaultComboBoxModel<String> levels = new DefaultComboBoxModel<String>();

		levels.addElement("SELECT LEVEL");
		levels.addElement(DifficultyLevel.HIGH.toString());
		levels.addElement(DifficultyLevel.MEDIUM.toString());
		levels.addElement(DifficultyLevel.LOW.toString());

		final JComboBox<String> levelCombo = new JComboBox<String>(levels);    

		levelCombo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				isLevelSelected = true;

				JComboBox<String> jcombo = (JComboBox<String>) e.getSource();

				if(String.valueOf(jcombo.getSelectedItem()).equals("HIGH")){
					diffLevel = DifficultyLevel.HIGH;}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("LOW")){
					diffLevel = DifficultyLevel.LOW;}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("MEDIUM")){
					diffLevel = DifficultyLevel.MEDIUM;
				} else if(String.valueOf(jcombo.getSelectedItem()).equals("SELECT LEVEL")){
					isLevelSelected= false;
				}

				if(isPlayerSelected && isGameTypeSelected){
					if(opponentPlayer == Player.Computer && isLevelSelected){
					playButton.setEnabled(true);
					}
					else if(opponentPlayer == Player.Human_2){
						playButton.setEnabled(true);
					}
					else{
						playButton.setEnabled(false);
					}
				}
				else{
					playButton.setEnabled(false);
				}



			}
		});

		JScrollPane levelsScrollPane = new JScrollPane(levelCombo); 
		
		levelCombo.setEnabled(false);
		
		final DefaultComboBoxModel<String> symbols = new DefaultComboBoxModel<String>();

		symbols.addElement("SELECT X|O");
		symbols.addElement("X");
		symbols.addElement("O");
		
		symbolCombo = new JComboBox<String>(symbols);
		
		symbolCombo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				JComboBox<String> jcombo = (JComboBox<String>) e.getSource();

				if(String.valueOf(jcombo.getSelectedItem()).equals("X")){
					humanSymbol = "X";
					computerSymbol="O";}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("O")){
					computerSymbol = "X";
					humanSymbol = "O";}

				
				if(isPlayerSelected && isGameTypeSelected){
					if(opponentPlayer == Player.Computer && isLevelSelected){
					playButton.setEnabled(true);
					}
					else if(opponentPlayer == Player.Human_2){
						playButton.setEnabled(true);
					}
					else{
						playButton.setEnabled(false);
					}
				}
				else{
					playButton.setEnabled(false);
				}

			}
		});
		
		JScrollPane symbolsScrollPane = new JScrollPane(symbolCombo); 
		
		symbolCombo.setEnabled(false);
		
		final DefaultComboBoxModel<String> opponents = new DefaultComboBoxModel<String>();

		opponents.addElement("SELECT OPP");
		opponents.addElement("COMPUTER");
		opponents.addElement("HUMAN");

		final JComboBox<String> opponentCombo = new JComboBox<String>(opponents);   

		opponentCombo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				isPlayerSelected = true;

				JComboBox<String> jcombo = (JComboBox<String>) e.getSource();

				if(String.valueOf(jcombo.getSelectedItem()).equals("COMPUTER")){
					opponentPlayer = Player.Computer;
					symbolCombo.setEnabled(true);
					levelCombo.setEnabled(true);
					winCompGames.setText("Computer Won");
					winHumanGames.setText("Human Won");
				}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("HUMAN")){
					opponentPlayer = Player.Human_2;
					symbolCombo.setEnabled(false);
					levelCombo.setEnabled(false);
					winCompGames.setText("Player_2");
					winHumanGames.setText("Player_1");
				}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("SELECT OPP")){
					symbolCombo.setEnabled(false);
					levelCombo.setEnabled(false);
					isPlayerSelected= false;
				}

				if(isPlayerSelected && isGameTypeSelected){
					if(opponentPlayer == Player.Computer && isLevelSelected){
					playButton.setEnabled(true);
					}
					else if(opponentPlayer == Player.Human_2){
						playButton.setEnabled(true);
					}
					else{
						playButton.setEnabled(false);
					}
				}
				else{
					playButton.setEnabled(false);
				}

			}



		});


		JScrollPane opponentScrollPane = new JScrollPane(opponentCombo); 

		JPanel northPanel = new JPanel();

		northPanel.setBackground(new Color(255, 255, 219));
		northPanel.add(symbolsScrollPane);
		northPanel.add(levelsScrollPane);
		northPanel.add(opponentScrollPane);
		northPanel.add(gameTypeScrollPane);
		

		playButtonPanel.add(statusLabel);
		bottomPanel.add(playButtonPanel,"North");
		
		JPanel resultPanel = new JPanel();
		JLabel totalGames = new JLabel("Total Games");
		totalNumber = new JLabel(String.valueOf(Game.totalGames));
		 winCompGames = new JLabel("Computer Won");
		winCompNumber = new JLabel(String.valueOf(Game.computerWinGames));

		 winHumanGames = new JLabel("Human Won");
		winHumanNumber = new JLabel(String.valueOf(Game.humanWinGames));

		resultPanel.add(totalGames);
		resultPanel.add(totalNumber);
		resultPanel.add(winCompGames);
		resultPanel.add(winCompNumber,"Center");
		resultPanel.add(winHumanGames,"South");
		resultPanel.add(winHumanNumber,"South");
		bottomPanel.add(resultPanel,"South");
		add(northPanel,"North");
		add(gridPanel,"Center");
		add(bottomPanel,"South");

		
		
		//add(resultPanel);
		playButton.addActionListener(this);
		helpButton.addActionListener(this);
		exitButton.addActionListener(this);




	}


	private void playBackground() {
		try{
			new JFXPanel();
			hit = new Media(Paths.get("Puzzle-Game.mp3").toUri().toString());
			mediaPlayer = new MediaPlayer(hit);
			mediaPlayer.play();

		}
		catch(Exception exception){
			exception.printStackTrace();
		}


	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public static void setStatus(String status){
		statusLabel.setText(status);
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String args[]){
		game.setVisible(true);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==playButton){
			playButton.setText("Reset");
			startGame();
			playBackground();
		}
		else if(e.getSource()==helpButton){
			JOptionPane.showMessageDialog(null, helpText);
		}
		else if(e.getSource()==exitButton){
			System.exit(0);
		}

	}

	/**
	 * Start game.
	 */
	private void startGame() {
		
		grid.enableTiles();
		currentPlayer = Player.Human;
		setStatus("Player 1's Turn!!");
		TileClick.resetTilesPos();
	}



	
	/**
	 * Gets the current player.
	 *
	 * @return the current player
	 */
	public static Player getCurrentPlayer(){
		return currentPlayer;
	}

}
