package algo.tictac;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.file.Paths;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import javafx.embed.swing.JFXPanel;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

// TODO: Auto-generated Javadoc
/**
 * The Class Game.
 * Author Amandeep Narula
 */
public class Game extends JFrame implements ActionListener{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The grid. */
	private static Grid grid;

	/** The tiles. */
	private Tile[][] tiles;

	/** The player. */
	public static Player currentPlayer;

	public static Player opponentPlayer;

	public static DifficultyLevel diffLevel;

	private boolean isLevelSelected = false;

	private boolean isPlayerSelected = false;

	private String helpText = "Tic-tac-toe (also known as Noughts and crosses" + "\n"
			+ " or Xs and Os) is a  game for two players" + "\n"
			+ " X and O, who take turns marking the spaces in a 3�3 grid. " + "\n"
			+ "The player who succeeds in placing three of their marks in a " + "\n"
			+ "horizontal, vertical, or diagonal row wins the game" 
			+ "\n"
			+ "Game of Tic-tac-toe, won by X" + "\n" +
			" The winner will get a gift";

	public static String computerSymbol;
	
	public static String humanSymbol;

	/** The status label. */
	private static JLabel statusLabel = new JLabel("");

	/** The play button. */
	JButton playButton = new JButton("Play");

	JButton helpButton = new JButton("Help");

	JButton exitButton = new JButton("Exit");

	/** The game. */
	private static Game game = new Game();

	Media hit;
	MediaPlayer mediaPlayer ;

	/**
	 * Gets the grid.
	 *
	 * @return the grid
	 */
	public static Grid getGrid(){
		return grid;
	}

	public static Game getGameInstance(){
		return game;
	}

	/**
	 * Instantiates a new game.
	 */
	 Game(){

		grid = new Grid();
		setTitle("Tic Tac Game - Team 8");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		JPanel gridPanel = new JPanel(new GridLayout(3,3));
		Font font = new Font("Arial",Font.BOLD, 32);


		tiles = grid.getTiles();
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++) {

				tiles[i][j].setFocusable(false);
				tiles[i][j].setFont(font);
				gridPanel.add(tiles[i][j]);
			}
		}

		setSize(350,350);
		this.add(gridPanel);



		JPanel labelPanel = new JPanel();

		labelPanel.add(statusLabel);

		JPanel playButtonPanel = new JPanel();
		playButtonPanel.add(playButton);
		playButtonPanel.add(helpButton);
		playButtonPanel.add(exitButton);
		playButton.setEnabled(false);
		playButtonPanel.setBackground(new Color(255, 255, 219));
		setStatus("Click 'Play' To Start");



		final DefaultComboBoxModel<String> levels = new DefaultComboBoxModel<String>();

		levels.addElement("SELECT LEVEL");
		levels.addElement(DifficultyLevel.HIGH.toString());
		levels.addElement(DifficultyLevel.MEDIUM.toString());
		levels.addElement(DifficultyLevel.LOW.toString());

		final JComboBox<String> levelCombo = new JComboBox<String>(levels);    

		levelCombo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				isLevelSelected = true;

				JComboBox<String> jcombo = (JComboBox<String>) e.getSource();

				if(String.valueOf(jcombo.getSelectedItem()).equals("HIGH")){
					diffLevel = DifficultyLevel.HIGH;}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("LOW")){
					diffLevel = DifficultyLevel.LOW;}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("MEDIUM")){
					diffLevel = DifficultyLevel.MEDIUM;
				}

				if(isLevelSelected && isPlayerSelected){
					playButton.setEnabled(true);
				}



			}
		});

		JScrollPane levelsScrollPane = new JScrollPane(levelCombo); 
		
		final DefaultComboBoxModel<String> symbols = new DefaultComboBoxModel<String>();

		symbols.addElement("SELECT X|O");
		symbols.addElement("X");
		symbols.addElement("O");
		
		final JComboBox<String> symbolCombo = new JComboBox<String>(symbols);
		
		symbolCombo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				JComboBox<String> jcombo = (JComboBox<String>) e.getSource();

				if(String.valueOf(jcombo.getSelectedItem()).equals("X")){
					humanSymbol = "X";
					TileClick.human1_symbol="X";
					computerSymbol="O";}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("O")){
					computerSymbol = "X";
					TileClick.human1_symbol="O";
					humanSymbol = "O";}


			}
		});
		
		JScrollPane symbolsScrollPane = new JScrollPane(symbolCombo); 
		
		final DefaultComboBoxModel<String> opponents = new DefaultComboBoxModel<String>();

		opponents.addElement("SELECT OPP");
		opponents.addElement("COMPUTER");
		opponents.addElement("HUMAN");

		final JComboBox<String> opponentCombo = new JComboBox<String>(opponents);   

		opponentCombo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				isPlayerSelected = true;

				JComboBox<String> jcombo = (JComboBox<String>) e.getSource();

				if(String.valueOf(jcombo.getSelectedItem()).equals("COMPUTER")){
					opponentPlayer = Player.Computer;
					TileClick.Total_games_played=0;
					TileClick.Opponent_type="COMPUTER";}
				else if(String.valueOf(jcombo.getSelectedItem()).equals("HUMAN")){
					opponentPlayer = Player.Human_2;
					TileClick.Total_games_played=0;
					TileClick.Opponent_type="HUMAN";}

				if(isLevelSelected && isPlayerSelected){
					playButton.setEnabled(true);
				}

			}



		});


		JScrollPane opponentScrollPane = new JScrollPane(opponentCombo); 

		JPanel northPanel = new JPanel();

		northPanel.setBackground(new Color(255, 255, 219));
		northPanel.add(symbolsScrollPane);
		northPanel.add(levelsScrollPane);
		northPanel.add(opponentScrollPane);
		

		playButtonPanel.add(statusLabel);

		JPanel resultPanel = new JPanel();
		JLabel totalGames = new JLabel("Total Games");
		JLabel totalNumber = new JLabel("0");
		JLabel winCompGames = new JLabel("Computer Won");
		JLabel winCompNumber = new JLabel("0");

		JLabel winHumanGames = new JLabel("Human Won");
		JLabel winHumanNumber = new JLabel("0");

		resultPanel.add(totalGames);
		resultPanel.add(totalNumber);
		resultPanel.add(winCompGames);
		resultPanel.add(winCompNumber,"Center");
		resultPanel.add(winHumanGames,"South");
		resultPanel.add(winHumanNumber,"South");
		playButtonPanel.add(resultPanel);
		add(northPanel,"North");
		add(gridPanel,"Center");
		add(playButtonPanel,"South");

		//add(resultPanel);
		playButton.addActionListener(this);
		helpButton.addActionListener(this);
		exitButton.addActionListener(this);




	}


	public void playBackground() {
		try{
			new JFXPanel();

			hit = new Media(Paths.get("Puzzle-Game.mp3").toUri().toString());
			mediaPlayer = new MediaPlayer(hit);
			mediaPlayer.play();

		}
		catch(Exception exception){
			exception.printStackTrace();
		}


	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public static void setStatus(String status){
		statusLabel.setText(status);
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String args[]){



		game.setVisible(true);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==playButton){
			playButton.setText("Reset");
			startGame();
			playBackground();
		}
		else if(e.getSource()==helpButton){
			JOptionPane.showMessageDialog(null, helpText);
		}
		else if(e.getSource()==exitButton){
			System.exit(0);
		}

	}

	/**
	 * Start game.
	 */
	public void startGame() {
		grid.enableTiles();
		currentPlayer = Player.Human;
		setStatus("Player 1's Turn!!");


	}


	/**
	 * Gets the current player.
	 *
	 * @return the current player
	 */
	public static Player getCurrentPlayer(){
		return currentPlayer;
	}

}
