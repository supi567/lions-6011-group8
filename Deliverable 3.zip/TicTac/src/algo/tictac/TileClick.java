package algo.tictac;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.file.Paths;
import java.util.Random;

import javax.swing.JOptionPane;

import javafx.embed.swing.JFXPanel;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;



// TODO: Auto-generated Javadoc
/**
 * The Class TileClick.
 * Author Amandeep Narula
 */
public class TileClick implements ActionListener{


	/**
	 * Instantiates a new tile click.
	 * 
	 */
	//	private AudioPlayer audioPlayer = AudioPlayer.player;
	//	private AudioStream audioStream ;
	//	private AudioData audioData;
	Media hit;
	MediaPlayer mediaPlayer ;
	static String human1_symbol="",Opponent_type="";
	private Player opponentPlayer;
	private DifficultyLevel diffLevel;
	int[][] tilesPos = new int[3][3];
	static int NumberOfGame_WinningBy_X=0,Total_games_played=0,Total_Number_Gameplayed_with_Computer=0;
	
	
	private static final int HumanCode=1;
	private static final int computerCode=2;

	public TileClick(){
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		Tile tile = (Tile) e.getSource();
        
		opponentPlayer = Game.opponentPlayer;
		diffLevel = Game.diffLevel;
		
		if(!tile.getText().equals(" ")){
			return;
		}
		
		

		if(Game.currentPlayer.equals(Player.Human)){
			playBackground(Game.currentPlayer);
			tilesPos[tile.getxVal()][tile.getyVal()] = HumanCode;
			if(human1_symbol.equals("X"))
			{
			tile.setText("X");
			}
			else
			{
				tile.setText("O");
			}
			
			int playerWon = checkGameState();
			if(playerWon ==1 || playerWon ==2 ){
                gameover(playerWon);
			}
			//Checks if opponent player is computer but not human and 
			//also reads the game
			if(opponentPlayer == Player.Computer){
				Total_Number_Gameplayed_with_Computer++;
				if(diffLevel == DifficultyLevel.HIGH){
				int pos[] = computerTurn();
				
				if(pos!=null){
					if(human1_symbol.equals("X"))
					{
				Game.getGrid().getTiles()[pos[0]][pos[1]].setText("O");
					}
					else
					{
						Game.getGrid().getTiles()[pos[0]][pos[1]].setText("X");
					}
				playerWon = checkGameState();
				if(playerWon ==1 || playerWon ==2 ){
	                gameover(playerWon);
				}
				return;
				} 
				
				for(int i=0;i<3;i++){
					for(int j=0;j<3;j++){
						if(Game.getGrid().getTiles()[i][j].getText().equals(" ")){
							if(human1_symbol.equals("X"))
							{
							Game.getGrid().getTiles()[i][j].setText("O");
							}
							else
							{
								Game.getGrid().getTiles()[i][j].setText("X");
							}
							
							tilesPos[Game.getGrid().getTiles()[i][j].getxVal()][Game.getGrid().getTiles()[i][j].getyVal()] = computerCode;
							playerWon = checkGameState();
							if(playerWon ==1 || playerWon ==2 ){
				                gameover(playerWon);
							}
							return;
						}
				}
				}
				}
				else if(diffLevel == DifficultyLevel.LOW){
					computerTurnLow();			
				}
				else if(diffLevel == DifficultyLevel.MEDIUM){
					computerTurnLow();	
				}
				
			}
			else{
				Game.currentPlayer = Player.Human_2;
				Game.setStatus("Player 2's Turn!!");
			}
			
			

		}
		else if (Game.currentPlayer.equals(Player.Human_2)){
			playBackground(Game.currentPlayer);
			if(human1_symbol.equals("X"))
			{
				tile.setText("O");
			}
			else
			{
				tile.setText("X");
			}
			int playerWon = checkGameState();
			if(playerWon ==1 || playerWon ==2 ){
                gameover(playerWon);
			}
			Game.currentPlayer = Player.Human;
			Game.setStatus("Player 1's Turn!!");
		}
	}

	private void computerTurnLow() {
		
		Random random = new Random();
		int min = 0;
		int max = 2;
		int iRandom = 0;
		int jRandom = 0;
		
		iRandom = random.nextInt(max - min + 1) + min;
		jRandom = random.nextInt(max - min + 1) + min;
	
		while(!Game.getGrid().getTiles()[iRandom][jRandom].getText().equals(" ")){
			iRandom = random.nextInt(max - min + 1) + min;
			jRandom = random.nextInt(max - min + 1) + min;
		}	
		if(human1_symbol.equals("X"))
		{
			Game.getGrid().getTiles()[iRandom][jRandom].setText("O");
		}
		else
		{
			Game.getGrid().getTiles()[iRandom][jRandom].setText("X");
		}
		
		return;
	}

	private int[] computerTurn() {	
       	int[] pos= new int[2];
		
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if(tilesPos[i][j] == 0){				
					tilesPos[i][j] = HumanCode;
					if(isHumanWinning()){
						pos[0] = i;
						pos[1] = j;
						tilesPos[i][j] = computerCode;
						return pos;
						
					} else{
						tilesPos[i][j]=0;
					}
					
				}
			
			}
			}
		return null;
	}

	

	private boolean isHumanWinning() {
		



		

		int o_Count=0;
		//int x_Count=0;

		//Checks Horizontally

		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){

				if(tilesPos[i][j]==HumanCode){
					o_Count++;
					System.out.println(o_Count);
					if(o_Count==3){
						System.out.println("Human WON");
						return true;
					}
				}
//				else if(tiles[i][j].getText().equals("X")){
//					x_Count++;
//					System.out.println(o_Count);
//					if(x_Count==3){
//						System.out.println("HUMAN WON");
//						return 2;
//					}
//				}

			}
			o_Count=0;
			//x_Count=0;
		}

		//Checks Vertically

		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){

				if(tilesPos[j][i]==HumanCode){
					o_Count++;
					System.out.println(o_Count);
					if(o_Count==3){
						System.out.println("human WON");
						return true;
					}
				}
//				else if(tiles[j][i].getText().equals("X")){
//					x_Count++;
//					System.out.println(o_Count);
//					if(x_Count==3){
//						System.out.println("HUMAN WON");
//						return 2;
//					}
//				}

			}
			o_Count=0;
			//x_Count=0;
		}

		//Checks Diagonally

		if(tilesPos[0][0]==HumanCode &&
				tilesPos[1][1]==HumanCode &&
				tilesPos[2][2]==HumanCode){
			System.out.println("human WON");
			return true;
		}
//		else if(tiles[0][0].getText().equals("X") &&
//				tiles[1][1].getText().equals("X") &&
//				tiles[2][2].getText().equals("X")){
//			System.out.println("HUMAN WON");
//			return 2;
//		}


		if(tilesPos[0][2]==HumanCode &&
				tilesPos[1][1]==HumanCode &&
				tilesPos[2][0]==HumanCode){
			System.out.println("humAN WON");
			return true;
		}
//		else if(tiles[0][2].getText().equals("X") &&
//				tiles[1][1].getText().equals("X") &&
//				tiles[2][0].getText().equals("X")){
//			System.out.println("HUMAN WON");
//			return 2;
//		}

		return false;
	
	}

	private void gameover(int playerWon) {
		String displayResult="";
		
		if(playerWon==1){
			
			displayResult= "Sorry!! You lose the game";
			Total_games_played++;
		}
		if(opponentPlayer == Player.Computer && playerWon==2){
			displayResult="Congratulations !! You've Won Tim Horton's Gift Card worth 5$ " + "\n"
		                  + "Your card number is TIM229";
			Total_games_played++;
		}
		if(opponentPlayer == Player.Human_2 && playerWon==2){
			NumberOfGame_WinningBy_X++;
			Total_games_played++;
			displayResult="Congratulations !! Player 1 has won  "+NumberOfGame_WinningBy_X +"  Out of "+Total_games_played+ " game";
			
		}
		if(Total_games_played==5){
			Total_games_played=0;
			
			if(NumberOfGame_WinningBy_X>=3)
			{
			
			JOptionPane.showMessageDialog(Game.getGameInstance(),
					"Player 1 has Won the Series",
				    "Game Result",
				    JOptionPane.WARNING_MESSAGE);
			NumberOfGame_WinningBy_X=0;
			
			}
			else
			{
				if(Opponent_type.equals("HUMAN")){
				JOptionPane.showMessageDialog(Game.getGameInstance(),
						"Player 2 has Won the Series",
					    "Game Result",
					    JOptionPane.WARNING_MESSAGE);
				}
				else if(Opponent_type.equals("COMPUTER") && NumberOfGame_WinningBy_X>=3 ){
					JOptionPane.showMessageDialog(Game.getGameInstance(),
							"Player 1 has Won the Series",
						    "Game Result",
						    JOptionPane.WARNING_MESSAGE);
				}
				else{
					JOptionPane.showMessageDialog(Game.getGameInstance(),
							"COMPUTER has Won the Series",
						    "Game Result",
						    JOptionPane.WARNING_MESSAGE);
				}
				
				NumberOfGame_WinningBy_X=0;
			}
		}
		else
		{
		if(NumberOfGame_WinningBy_X < 5)
		{
		JOptionPane.showMessageDialog(Game.getGameInstance(),
				displayResult,
			    "Game Result",
			    JOptionPane.WARNING_MESSAGE);
		System.out.println("Player  won");
		}
		}
		
	}

	private void playBackground(Player player) {
		try{
			new JFXPanel();
			if(Game.currentPlayer.equals(Player.Human)){
				hit = new Media(Paths.get("beep3.mp3").toUri().toString());
				mediaPlayer = new MediaPlayer(hit);
				mediaPlayer.play();
			}
			else if(Game.currentPlayer.equals(Player.Computer)){
				hit = new Media(Paths.get("beep14.mp3").toUri().toString());
				mediaPlayer = new MediaPlayer(hit);
				mediaPlayer.play();
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}


	}

	/**
	 * Check game state.
	 *
	 * @return the int
	 */
	private int checkGameState() {


		Tile[][] tiles = Game.getGrid().getTiles();

		int o_Count=0;
		int x_Count=0;

		//Checks Horizontally

		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){

				if(tiles[i][j].getText().equals("O")){
					o_Count++;
					System.out.println(o_Count);
					if(o_Count==3){
						System.out.println("COMPUTER WON");
						if(human1_symbol.equals("O"))
						{
						return 2;
						}
						else
						{
							return 1;
						}
						
					}
				}
				else if(tiles[i][j].getText().equals("X")){
					x_Count++;
					System.out.println(o_Count);
					if(x_Count==3){
						System.out.println("HUMAN WON");
						if(human1_symbol.equals("O"))
						{
						return 1;
						}
						else
						{
							return 2;
						}
						
					}
				}

			}
			o_Count=0;
			x_Count=0;
		}

		//Checks Vertically

		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){

				if(tiles[j][i].getText().equals("O")){
					o_Count++;
					System.out.println(o_Count);
					if(o_Count==3){
						System.out.println("COMPUTER WON");
						if(human1_symbol.equals("O"))
						{
						return 2;
						}
						else
						{
							return 1;
						}
						
					}
				}
				else if(tiles[j][i].getText().equals("X")){
					x_Count++;
					System.out.println(o_Count);
					if(x_Count==3){
						System.out.println("HUMAN WON");
						if(human1_symbol.equals("O"))
						{
						return 1;
						}
						else
						{
							return 2;
						}
						
					}
				}

			}
			o_Count=0;
			x_Count=0;
		}

		//Checks Diagonally

		if(tiles[0][0].getText().equals("O") &&
				tiles[1][1].getText().equals("O") &&
				tiles[2][2].getText().equals("O")){
			System.out.println("COMPUTER WON");
			if(human1_symbol.equals("O"))
			{
			return 2;
			}
			else
			{
				return 1;
			}
		}
		else if(tiles[0][0].getText().equals("X") &&
				tiles[1][1].getText().equals("X") &&
				tiles[2][2].getText().equals("X")){
			System.out.println("HUMAN WON");
			if(human1_symbol.equals("O"))
			{
			return 1;
			}
			else
			{
				return 2;
			}
			
		}


		if(tiles[0][2].getText().equals("O") &&
				tiles[1][1].getText().equals("O") &&
				tiles[2][0].getText().equals("O")){
			System.out.println("COMPUTER WON");
			if(human1_symbol.equals("O"))
			{
			return 2;
			}
			else
			{
				return 1;
			}
			
		}
		else if(tiles[0][2].getText().equals("X") &&
				tiles[1][1].getText().equals("X") &&
				tiles[2][0].getText().equals("X")){
			System.out.println("HUMAN WON");
			if(human1_symbol.equals("O"))
			{
			return 1;
			}
			else
			{
				return 2;
			}
		}

		return 0;
	}
}
