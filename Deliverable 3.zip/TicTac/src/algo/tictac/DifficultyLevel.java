package algo.tictac;

// TODO: Auto-generated Javadoc
/**
 * The Enum DifficultyLevel.
 * Author Amandeep Narula
 */
public enum DifficultyLevel {
 
 /** The high. */
 HIGH("HIGH"),
/** The medium. */
MEDIUM("MEDIUM"),
/** The low. */
LOW("LOW");
 
 /** The level. */
 private String level;
  
 /**
  * Instantiates a new difficulty level.
  *
  * @param level the level
  */
 DifficultyLevel(String level){
	 this.level=level;
	 
 }
 
 /* (non-Javadoc)
  * @see java.lang.Enum#toString()
  */
 public String toString(){
	 return level;
	 
 }
}
