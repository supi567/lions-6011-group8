package algo.tictac;

public enum Player {
      Human,Computer,Human_2 
}
